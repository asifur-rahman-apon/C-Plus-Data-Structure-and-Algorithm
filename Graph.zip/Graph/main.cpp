#include <iostream>
#include "graphtype.cpp"
using namespace std;

int main()
{
    GraphType<char> graph(8);

    // Add vertices
    graph.AddVertex('A');
    graph.AddVertex('B');
    graph.AddVertex('C');
    graph.AddVertex('D');
    graph.AddVertex('E');
    graph.AddVertex('F');
    graph.AddVertex('G');
    graph.AddVertex('H');

    // ACTUAL EDGES (Directed)
    graph.AddEdge('B','A',1);
    graph.AddEdge('A','B',1);
    graph.AddEdge('A','C',1);
    graph.AddEdge('A','D',1);
    graph.AddEdge('D','A',1);
    graph.AddEdge('D','E',1);
    graph.AddEdge('D','G',1);
    graph.AddEdge('G','F',1);
    graph.AddEdge('F','H',1);
    graph.AddEdge('H','E',1);

    // Outdegree of D
    cout << "Outdegree of D: "
         << graph.OutDegree('D') << endl;
    cout << "Indegree of D: " << graph.InDegree('D') << endl;

    // Edge checks
    cout << "Edge between A and D: ";
    if (graph.FoundEdge('A','D'))
        cout << "There is an edge." << endl;
    else
        cout << "There is no edge." << endl;

    cout << "Edge between B and D: ";
    if (graph.FoundEdge('B','D'))
        cout << "There is no edge." << endl;
    else
        cout << "There is an edge." << endl;

    // DFS
    cout << "\nDFS from B to E:\n";
    graph.DepthFirstSearch('B','E');

    cout << "\nDFS from E to B:\n";
    graph.DepthFirstSearch('E','B');

    // BFS
    cout << "\nBFS from B to E:\n";
    graph.BreadthFirstSearch('B','E');

    cout << "\nBFS from E to B:\n";
    graph.BreadthFirstSearch('E','B');

    // Shortest Path BFS
    cout << "\nBFS (Shortest Path) from B to E:\n";
    int length = graph.BreadthFirstSearchShortest('B','E');
    cout << "\nLength of shortest path from B to E: "
         << length << endl;

    return 0;
}
