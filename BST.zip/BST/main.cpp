#include <iostream>
#include "binarysearchtree.cpp"

using namespace std;

int main()
{
    TreeType<int> tree;
    bool found;
    int item;

    // Check if tree is empty
    if (tree.IsEmpty())
        cout << "Tree is empty" << endl;
    else
        cout << "Tree is not empty" << endl;

    // Insert 10 items
    int values[10] = {4, 9, 2, 7, 3, 11, 17, 0, 5, 1};
    for (int i = 0; i < 10; i++)
        tree.InsertItem(values[i]);

    // Check again if tree is empty
    if (tree.IsEmpty())
        cout << "Tree is empty" << endl;
    else
        cout << "Tree is not empty" << endl;

    // Print length of the tree
    cout << "Length of tree is: " << tree.LengthIs() << endl;
    cout << "Height of tree is: " << tree.HeightIs() << endl;
    cout << "Total levels of tree: " << tree.TotalLevel() << endl;
    cout << "Level of 4: " << tree.LevelOf(4) << endl;
    // Retrieve 9
    item = 9;
    tree.RetrieveItem(item, found);
    if (found)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    // Retrieve 13
    item = 13;
    tree.RetrieveItem(item, found);
    if (found)
        cout << "Item is found" << endl;
    else
        cout << "Item is not found" << endl;

    // Inorder traversal
    cout << "Inorder traversal: ";
    tree.ResetTree(IN_ORDER);
    bool finished = false;
    while (!finished)
    {
        tree.GetNextItem(item, IN_ORDER, finished);
        cout << item << " ";
    }
    cout << endl;

    // Preorder traversal
    cout << "Preorder traversal: ";
    tree.ResetTree(PRE_ORDER);
    finished = false;
    while (!finished)
    {
        tree.GetNextItem(item, PRE_ORDER, finished);
        cout << item << " ";
    }
    cout << endl;

    // Postorder traversal
    cout << "Postorder traversal: ";
    tree.ResetTree(POST_ORDER);
    finished = false;
    while (!finished)
    {
        tree.GetNextItem(item, POST_ORDER, finished);
        cout << item << " ";
    }
    cout << endl;

    // Make tree empty
    tree.MakeEmpty();
    cout << "Tree has been made empty" << endl;

    // Best ordering (minimum height BST)



    int sortedArr[10] = {0, 1, 2, 3, 4, 5, 7, 9, 11, 17};

    // Build minimum height BST
    BuildMinHeightBST( sortedArr, 0, 9);




    cout << endl;


    return 0;
}
